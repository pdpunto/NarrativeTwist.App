import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/LobbyPage.css';
import Sidebar from '../components/Sidebar';



const LobbyPage = () => {
    console.log("Renderizando LobbyPage");
    const Navigate = useNavigate();


    const handleCreateRoom = () => {
        Navigate('/create-room');
    };

    const handleJoinRoom = () => {
        Navigate('/join-room');
    };

    return (
        <div>
            <div className="app-layout">
            <Sidebar />
                <div className="button-group">
                    <button onClick={handleCreateRoom}>Crear Sala</button>
                    <button onClick={handleJoinRoom}>Unirse a Sala</button>
                </div>
            </div>
        </div>
    
    );
};


export default LobbyPage;

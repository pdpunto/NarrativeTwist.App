import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../services/axiosConfig';
import '../styles/JoinRoomPage.css';
import Sidebar from '../components/Sidebar';

function JoinRoomPage() {
  const [roomCode, setRoomCode] = useState('');
  const navigate = useNavigate();

  const handleJoinRoom = async (e) => {
    e.preventDefault();

    try {
      // Verificar si la sala existe (hacer una solicitud POST a /join-room)
      const response = await axios.post('/join-room', { roomCode });
      // Si la sala existe, redirige al usuario a la sala
      navigate(`/room/${roomCode}`);
    } catch (error) {
      console.error('Error al unirse a la sala:', error);
      // Si la sala no existe o hay otro error, muestra un mensaje al usuario
      alert('Error al unirse a la sala. Por favor, verifica el código e inténtalo de nuevo.');
    }
  };

  return (
    <div>
      <div className="app-layout">
            <Sidebar />
      <div className="join-room-container">
        <form onSubmit={handleJoinRoom}>
          <div className="form-group">
            <label htmlFor="roomCode">Código de Sala</label>
            <input
              type="text"
              id="roomCode"
              value={roomCode}
              onChange={(e) => setRoomCode(e.target.value)}
            />
          </div>
          <button type="submit">Unirse a Sala</button>
        </form>
      </div>
    </div>
    </div>
  );
}

export default JoinRoomPage;

import {
    faBars, faCogs,
    faPencilAlt,
    faPlus, faSearch,
    faSignOutAlt, faTimes,
    faTrashAlt
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { jwtDecode } from 'jwt-decode';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from '../services/axiosConfig';
import '../styles/Sidebar.css';
import AjustesUsuario from './AjustesUsuario';

const Sidebar = () => {
    const [isSidebarVisible, setIsSidebarVisible] = useState(true);
    const [salasCreadas, setSalasCreadas] = useState([]);
    const [salasParticipadas, setSalasParticipadas] = useState([]);
    const [userInfo, setUserInfo] = useState({ Username: '', ProfilePicture: '' });
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isAjustesUsuarioVisible, setIsAjustesUsuarioVisible] = useState(false);
    const [editingRoomId, setEditingRoomId] = useState(null); // Nuevo estado
    const [customName, setCustomName] = useState(''); // Nuevo estado
    const navigate = useNavigate();

    const getUserIdFromToken = () => {
        const token = localStorage.getItem('token');
        if (token) {
            const decodedToken = jwtDecode(token);
            return decodedToken.userId;
        }
        return null;
    };

    const openAjustesUsuario = () => setIsAjustesUsuarioVisible(true);
    const closeAjustesUsuario = () => setIsAjustesUsuarioVisible(false);

    useEffect(() => {
        const cargarSalas = async () => {
            const userId = getUserIdFromToken();
            if (userId) {
                try {
                    const salasResponse = await axios.get(`/user-rooms/${userId}`);
                    setSalasCreadas(salasResponse.data.filter(sala => sala.IsCreator));
                    setSalasParticipadas(salasResponse.data.filter(sala => !sala.IsCreator));

                    const userInfoResponse = await axios.get(`/user-info/${userId}`);
                    setUserInfo(userInfoResponse.data);
                } catch (error) {
                    console.error('Error al cargar salas o información del usuario:', error);
                }
            }
        };
        cargarSalas();
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('token');
        navigate('/');
    };

    const navigateToRoom = (roomCode) => {
        if (editingRoomId === null) {
            navigate(`/room/${roomCode}`);
        }
    };

    const toggleSidebar = () => setIsSidebarVisible(!isSidebarVisible);
    const renderProfilePicture = () => {
        const initial = userInfo.DisplayName ? userInfo.DisplayName[0].toUpperCase()
            : userInfo.Username ? userInfo.Username[0].toUpperCase()
            : 'U';

        return userInfo.ProfilePicture
            ? <img src={userInfo.ProfilePicture} alt="Profile" className="profile-picture" />
            : <div className="profile-picture-placeholder">{initial}</div>;
    };

    const toggleUserMenu = () => setIsMenuOpen(!isMenuOpen);

    const handleCustomNameChange = (e) => {
        setCustomName(e.target.value);
    };

    const startEditing = (sala) => {
        setEditingRoomId(sala.RoomID); // Solo almacena el ID de la sala que se va a editar
        setCustomName(sala.CustomRoomName || sala.RoomCode);
    };
    
    const submitRename = async (roomId, roomCode) => {
        if (!roomId || !roomCode) return;
    
        try {
            await axios.put(`/rename-room/${roomCode}`, { customRoomName: customName });
            const updatedSalas = salasCreadas.map(sala => {
                if (sala.RoomID === roomId) {
                    return { ...sala, CustomRoomName: customName };
                }
                return sala;
            });
            setSalasCreadas(updatedSalas);
            setEditingRoomId(null); // Restablecer el ID de edición
        } catch (error) {
            console.error('Error al renombrar la sala:', error);
        }
    };
    
    // Función para eliminar una sala
    const eliminarSala = async (roomId) => {
        // Aquí va la lógica para eliminar la sala
        console.log(`Eliminar sala con ID: ${roomId}`);
        try {
            await axios.delete(`/delete-room/${roomId}`);
            setSalasCreadas(salasCreadas.filter(sala => sala.RoomID !== roomId));
        } catch (error) {
            console.error('Error al eliminar la sala:', error);
        }
    };

    // Función para esconder una sala de la lista de "Otras Salas"
    const esconderSala = async (roomCode) => {
        console.log(`Eliminar sala con código: ${roomCode} de la lista del usuario`);
        try {
            // Aquí haces una solicitud al endpoint del servidor que eliminará la sala de la lista del usuario
            await axios.delete(`/remove-room-from-list/${roomCode}`);
            // Actualizar el estado para reflejar que la sala se ha eliminado de la lista del usuario
            setSalasParticipadas(salasParticipadas.filter(sala => sala.RoomCode !== roomCode));
        } catch (error) {
            console.error('Error al eliminar la sala de la lista:', error);
        }
    };
  
    return (
        <div className={`sidebar ${isSidebarVisible ? 'visible' : 'hidden'}`}>
            <button className="toggle-sidebar" onClick={toggleSidebar}>
                <FontAwesomeIcon icon={isSidebarVisible ? faTimes : faBars} />
            </button>
    
            <div className="sidebar-content">
                <div className="title-with-button">
                    <button onClick={() => navigate('/create-room')} className="icon-button">
                        <FontAwesomeIcon icon={faPlus} style={{ color: '#0b1e2b' }} />
                    </button>
                    <h3>Mis Salas</h3>
                </div>
    
                <ul className="salas-lista">
                {salasCreadas.map(sala => (
                    <li key={sala.RoomID}>
                        {editingRoomId === sala.RoomID ? (
                            <input
                                type="text"
                                value={customName}
                                onChange={handleCustomNameChange}
                                onBlur={() => submitRename(sala.RoomID, sala.RoomCode)}
                            />
                        ) : (
                            <div onClick={() => navigateToRoom(sala.RoomCode)}>
                                <span>{sala.CustomRoomName || sala.RoomCode}</span>
                                {sala.CustomRoomName && (
                                    <div style={{ fontSize: 'smaller' }}>{sala.RoomCode}</div>
                                )}
                            </div>
                        )}
                        <button onClick={() => startEditing(sala)} className="icon-button">
                            <FontAwesomeIcon icon={faPencilAlt} />
                        </button>
                        <button onClick={() => eliminarSala(sala.RoomID)} className="icon-button">
                            <FontAwesomeIcon icon={faTrashAlt} />
                        </button>
                    </li>
                ))}
                </ul>
    
                <div className="title-with-button">
                    <button onClick={() => navigate('/join-room')} className="icon-button">
                        <FontAwesomeIcon icon={faSearch} style={{ color: '#0b1e2b' }} />
                    </button>
                    <h3>Otras Salas</h3>
                </div>
    
                <ul className="salas-lista">
                {salasParticipadas.map(sala => (
                    <li key={sala.RoomID}>
                        <Link to={`/room/${sala.RoomCode}`}>{sala.RoomCode}</Link>
                        <button onClick={() => esconderSala(sala.RoomCode)} className="icon-button">
                            <FontAwesomeIcon icon={faTrashAlt} />
                        </button>
                    </li>
                ))}
                </ul>
    
                <div className="user-profile" onClick={toggleUserMenu}>
                    {renderProfilePicture()}
                    <div className="user-info">
                        <span className="user-nick">{userInfo.DisplayName || 'Usuario'}</span>
                        <span className="user-fullname">{userInfo.Username}</span>
                    </div>
                </div>
    
                {isMenuOpen && (
                    <div className="user-menu">
                        <button onClick={openAjustesUsuario} className="menu-item">
                            <FontAwesomeIcon icon={faCogs} />
                            Ajustes de Usuario
                        </button>
                        <button onClick={handleLogout} className="menu-item">
                            <FontAwesomeIcon icon={faSignOutAlt} />
                            Cerrar Sesión
                        </button>
                    </div>
                )}
            </div>
    
            {isAjustesUsuarioVisible && (
                <AjustesUsuario onClose={closeAjustesUsuario} />
            )}
        </div>
    );
    
    
  };
  
  export default Sidebar;
  
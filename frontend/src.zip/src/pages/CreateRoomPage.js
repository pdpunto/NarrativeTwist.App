import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import KeywordsInput from '../components/KeywordsInput';
import Sidebar from '../components/Sidebar';
import axios from '../services/axiosConfig';
import '../styles/CreateRoomPage.css';

const CreateRoomPage = () => {
    const [maxInteractions, setMaxInteractions] = useState(10);
    const [isPublic, setIsPublic] = useState(false);
    const [keywords, setKeywords] = useState('');
    const [totalRooms, setTotalRooms] = useState(0); // Estado para el total de salas creadas
    const navigate = useNavigate();

    useEffect(() => {
        // Consultar el número total de salas creadas por el usuario
        const fetchTotalRooms = async () => {
            try {
                const response = await axios.get('/user-total-rooms');
                setTotalRooms(response.data.totalRooms);
            } catch (error) {
                console.error('Error al obtener el total de salas:', error);
            }
        };

        fetchTotalRooms();
    }, []);

    const handleCreateRoom = async (e) => {
        e.preventDefault();
        if (totalRooms >= 4) {
            alert('Has alcanzado el límite de salas que puedes crear. Elimina una sala existente para crear una nueva.');
            return;
        }

        try {
            const response = await axios.post('/create-room', { maxInteractions, isPublic, keywords });
            navigate('/room/' + response.data.roomCode);
            // Actualizar el estado para reflejar la sala recién creada
            setTotalRooms(totalRooms + 1);
        } catch (error) {
            console.error('Error al crear la sala:', error);
        }
    };
    
    return (
        <div className="app-layout">
            <Sidebar />
            <div className="create-room-container">
                
                <form onSubmit={handleCreateRoom}>
                    <div className="form-group">
                        <label htmlFor="maxInteractions">Máximo de Interacciones</label>
                        <input
                            type="number"
                            id="maxInteractions"
                            value={maxInteractions}
                            onChange={(e) => setMaxInteractions(e.target.value)}
                            min="1"
                        />
                    </div>
                    <div className="form-group">
                        <label>
                            <input
                                type="checkbox"
                                checked={isPublic}
                                onChange={(e) => setIsPublic(e.target.checked)}
                            />
                            Sala Pública
                        </label>
                    </div>
                    <div className="form-group">
                    <KeywordsInput onKeywordsChange={setKeywords} />
                       </div>
                       <button type="submit" disabled={totalRooms >= 4}>Crear Sala</button>
                </form>
                {totalRooms >= 4 && (
                    <p>Has alcanzado el límite total de salas. Elimina una sala para poder crear una nueva.</p>
                )}
            </div>
        </div>
    );
};

export default CreateRoomPage;
